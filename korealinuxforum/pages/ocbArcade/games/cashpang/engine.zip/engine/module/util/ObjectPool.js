define("util/ObjectPool", function(){
    /**
     * util/ObjectPool 객체 풀 모듈
     * @exports util/ObjectPool
     * @param {Function} ConstructorFunction 생성자 함수
     * @param {Number} expandCount    객체 풀에 생성해 놓을 객체의 개수
     */
    var ObjectPool = function(ConstructorFunction, expandCount){
        this._ConstructorFunction = ConstructorFunction;

        this._pool = [];
        this._allocated = [];

        this.expand(expandCount || 0);
    };

    /**
     * 객체 풀에서 객체를 하나 가져온다.
     * @method
     * @return {Object} 객체
     */
    ObjectPool.prototype.allocate = function() {
        var obj;

        if (this._pool.length === 0) {
            this.expand(16);
        }

        obj = this._pool.splice(0, 1)[0]; //FIFO
        this._ConstructorFunction.apply(obj, arguments);
        this._allocated.push(obj);

        return obj;
    };

    /**
     * 객체를 다시 풀로 되돌려서 사용가능한 상태로 만든다.
     * @param  {Object} obj 반환할 객체
     * @return {ObjectPool}
     */
    ObjectPool.prototype.free = function(obj) {
        var index = this._allocated.indexOf(obj);
        if (index > -1) {
            this._allocated.splice(index, 1);
            this._pool.push(obj);

            // for (var k in obj) {
            //     delete obj[k];
            // }
            this.reset(obj);
        }

        return this;
    };

    /**
     * 객체를 초기화시킨다.
     * @param  {Object} obj 반환할 객체
     * @return {Object} 초기화된 객체
     */
    ObjectPool.prototype.reset = function(obj) {
        this._ConstructorFunction.call(obj);

        for (var key in this._ConstructorFunction.prototype) { //delete overided props
            if (this._ConstructorFunction.prototype.hasOwnProperty(key) && obj.hasOwnProperty(key)) {
                delete obj[key];
            }
        }

        return obj;
    };

    /**
     * 객체 풀을 확장한다.
     * @param  {Number} n 객체 풀에 확장하여 할당해 놓을 객체의 개수
     * @return {ObjectPool}
     */
    ObjectPool.prototype.expand = function(n) {
        var obj;
        while (n--) {
            obj = new this._ConstructorFunction();
            obj._objectPool = this;
            this._pool.push(obj);
        }

        return this;
    };

    return ObjectPool;
});